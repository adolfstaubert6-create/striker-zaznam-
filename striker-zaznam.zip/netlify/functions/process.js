const https = require('https');

exports.handler = async function(event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON' }) };
  }

  const { text } = body;
  if (!text) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Chýba text' }) };
  }

  const OPENAI_KEY = process.env.OPENAI_API_KEY;
  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_KEY = process.env.SUPABASE_KEY;

  // 1. Call OpenAI
  const prompt = `Si asistent ktorý spracúva záznamy z pracovných stretnutí alebo správ.
Zo zadaného textu extrahuj informácie a vráť IBA čistý JSON bez akýchkoľvek backtick-ov alebo markdown formátovania.

JSON musí mať PRESNE túto štruktúru:
{
  "datum": "dátum v tvare YYYY-MM-DD alebo dnes ak nie je uvedený",
  "co_sa_riesilo": "čo sa riešilo / téma",
  "vysledok": "výsledok / záver",
  "problem": "problém ak bol, inak prázdny string",
  "ulohy_staubert": ["úloha1", "úloha2"],
  "ulohy_szabo": ["úloha1", "úloha2"],
  "dalsi_krok": "ďalší krok"
}

Text na spracovanie:
${text}`;

  let aiResult;
  try {
    aiResult = await callOpenAI(OPENAI_KEY, prompt);
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: 'OpenAI chyba: ' + e.message }) };
  }

  let parsed;
  try {
    const clean = aiResult.replace(/```json|```/g, '').trim();
    parsed = JSON.parse(clean);
  } catch {
    return { statusCode: 500, body: JSON.stringify({ error: 'AI vrátil neplatný JSON', raw: aiResult }) };
  }

  // 2. Save to Supabase
  try {
    await saveToSupabase(SUPABASE_URL, SUPABASE_KEY, parsed);
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: 'Supabase chyba: ' + e.message }) };
  }

  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(parsed)
  };
};

function callOpenAI(apiKey, prompt) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify({
      model: 'gpt-4o-mini',
      max_tokens: 1000,
      messages: [{ role: 'user', content: prompt }]
    });

    const options = {
      hostname: 'api.openai.com',
      path: '/v1/chat/completions',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
        'Content-Length': Buffer.byteLength(payload)
      }
    };

    const req = https.request(options, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (json.error) return reject(new Error(json.error.message));
          resolve(json.choices[0].message.content);
        } catch (e) {
          reject(e);
        }
      });
    });

    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

function saveToSupabase(url, key, data) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(data);

    const urlObj = new URL(`${url}/rest/v1/zaznam`);

    const options = {
      hostname: urlObj.hostname,
      path: urlObj.pathname,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': key,
        'Authorization': `Bearer ${key}`,
        'Prefer': 'return=minimal',
        'Content-Length': Buffer.byteLength(payload)
      }
    };

    const req = https.request(options, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve();
        } else {
          reject(new Error(`Supabase status ${res.statusCode}: ${data}`));
        }
      });
    });

    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}
